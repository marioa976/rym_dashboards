<?php
/**
 * QroBici Analytics — Configuración
 * ------------------------------------------------------------
 * Edita estos valores con tus credenciales reales antes de
 * publicar el reporte. NO subas este archivo a un repo público.
 */

return [

    // ---------- Base de datos MariaDB ----------
    'db' => [
        'host'    => '127.0.0.1',
        'port'    => 3306,
        'name'    => 'qrobici',          // nombre de la BD
        'user'    => 'usuario_lectura',
        'pass'    => 'tu_password_aqui',
        'charset' => 'utf8mb4',
    ],

    // ---------- Nombres de las vistas ----------
    'vistas' => [
        'viajes' => 'viajes',     // vista con las 21 columnas de viajes
        'planes' => 'planes',     // vista con las 9 columnas de planes
    ],

    // ---------- Google Maps ----------
    // Necesita habilitada la "Maps JavaScript API" en console.cloud.google.com
    // Se imprime al cliente en el HTML, así que restringe la llave por dominio.
    'google_maps_api_key' => 'AIzaSy...PEGAR_AQUI...',

    // ---------- Rango de fechas a analizar ----------
    // null = sin filtro (todo el histórico de la vista)
    // o pon fechas tipo '2026-05-01 00:00:00' / '2026-05-31 23:59:59'
    'fecha_desde' => null,
    'fecha_hasta' => null,

    // ---------- Opciones de presentación ----------
    'titulo'         => 'Reporte integral de viajes y recorridos QroBici',
    'subtitulo'      => 'Análisis de uso, demografía, estaciones y rutas del sistema de bicicleta pública de Querétaro.',
    'zona_horaria'   => 'America/Mexico_City',
    'cache_segundos' => 0,           // 0 = siempre en vivo. Pon 300 para cachear 5 min.

    // ---------- Factores de estimación ambiental ----------
    'co2_g_por_km'        => 210,    // ~210 g CO2 evitado por km vs. auto
    'calorias_por_km'     => 40,     // ~40 kcal quemadas por km

    // ---------- Debug ----------
    // true = muestra errores de SQL/PHP en pantalla; false = silencioso en producción
    'debug' => false,
];
